# Grafika Komputer dan Pengolahan Citra

Tugas Pertemuan 9 - Operasi Geometri pada Citra Digital (Image Manipulation)

## Isi repository

| Folder | Deskripsi | Teknologi |
|---|---|---|
| `praktikum_pengolahan_citra/` | Aplikasi web upload foto dan pengolahan citra (resize, crop, flip, grayscale, brightness) | Python, Flask, OpenCV, HTML, CSS |
| `praktikum_operasi_geometri/` | Program resize, crop, dan flip pada sebuah foto, hasil tersimpan di folder `output` | Python, OpenCV |

## Cara menjalankan

Aplikasi web Flask:
```
cd praktikum_pengolahan_citra
pip install -r requirements.txt
python app.py
```
Buka http://127.0.0.1:5000 di browser.

Program operasi geometri:
```
cd praktikum_operasi_geometri
pip install -r requirements.txt
python operasi_geometri.py
```
