import cv2
import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PATH_FOTO = os.path.join(BASE_DIR, "foto.jpg")
FOLDER_OUTPUT = os.path.join(BASE_DIR, "output")

os.makedirs(FOLDER_OUTPUT, exist_ok=True)

gambar = cv2.imread(PATH_FOTO)

if gambar is None:
    print("Gambar foto.jpg tidak ditemukan atau tidak dapat dibaca!")
    sys.exit(1)

tinggi, lebar = gambar.shape[:2]
print("Ukuran gambar asli :", lebar, "x", tinggi, "piksel")

resize = cv2.resize(gambar, (300, 300))

flip = cv2.flip(gambar, 1)

crop = gambar[250:600, 200:480]

hasil = {
    "gambar_asli": gambar,
    "resize": resize,
    "flip": flip,
    "crop": crop,
}

for nama, img in hasil.items():
    path_simpan = os.path.join(FOLDER_OUTPUT, nama + ".jpg")
    cv2.imwrite(path_simpan, img)
    print("Tersimpan:", path_simpan)

try:
    cv2.imshow("Gambar Asli", gambar)
    cv2.imshow("Resize", resize)
    cv2.imshow("Flip", flip)
    cv2.imshow("Crop", crop)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
except cv2.error:
    print("Jendela tampilan tidak tersedia, hasil dapat dilihat di folder output.")
