# Praktikum Operasi Geometri pada Citra Digital (Resize, Crop, Flip)

Praktikum Grafika Komputer dan Pengolahan Citra - Pertemuan 9

## Struktur folder
```
praktikum_operasi_geometri/
├── operasi_geometri.py
├── foto.jpg
├── requirements.txt
├── README.md
└── output/
    ├── gambar_asli.jpg
    ├── resize.jpg
    ├── flip.jpg
    └── crop.jpg
```

## Install library
```
pip install opencv-python
```

## Menjalankan program
```
cd praktikum_operasi_geometri
python operasi_geometri.py
```
Empat jendela akan tampil (Gambar Asli, Resize, Flip, Crop). Tekan tombol apa saja untuk menutup.
Hasil juga otomatis tersimpan di folder `output`.
