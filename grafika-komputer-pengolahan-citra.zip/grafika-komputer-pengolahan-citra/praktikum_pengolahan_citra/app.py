from flask import Flask, render_template, request, url_for, send_from_directory
import cv2
import os
import uuid
from werkzeug.utils import secure_filename

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
OUTPUT_FOLDER = os.path.join(BASE_DIR, "hasil_foto")

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024

EKSTENSI_BOLEH = [".jpg", ".jpeg", ".png"]


@app.route("/", methods=["GET", "POST"])
def index():
    hasil = {}

    if request.method == "POST":
        file = request.files.get("foto")

        if not file or file.filename == "":
            return render_template(
                "index.html", hasil=hasil,
                error="Silakan pilih foto terlebih dahulu!"
            )

        filename = secure_filename(file.filename)
        ekstensi = os.path.splitext(filename)[1].lower()

        if ekstensi not in EKSTENSI_BOLEH:
            return render_template(
                "index.html", hasil=hasil,
                error="Format foto harus JPG, JPEG, atau PNG!"
            )

        nama_unik = str(uuid.uuid4())
        nama_file = nama_unik + ekstensi
        path_upload = os.path.join(UPLOAD_FOLDER, nama_file)
        file.save(path_upload)

        gambar = cv2.imread(path_upload)

        if gambar is None:
            os.remove(path_upload)
            return render_template(
                "index.html", hasil=hasil,
                error="Gambar tidak dapat dibaca!"
            )

        tinggi, lebar = gambar.shape[:2]

        if tinggi < 4 or lebar < 4:
            os.remove(path_upload)
            return render_template(
                "index.html", hasil=hasil,
                error="Ukuran foto terlalu kecil (minimal 4 x 4 piksel)!"
            )

        resize = cv2.resize(gambar, (300, 400))

        crop = gambar[
            tinggi // 4: 3 * tinggi // 4,
            lebar // 4: 3 * lebar // 4
        ]

        flip = cv2.flip(gambar, 1)

        gray = cv2.cvtColor(gambar, cv2.COLOR_BGR2GRAY)

        bright = cv2.convertScaleAbs(gambar, alpha=1, beta=50)

        hasil["original"] = url_for("uploaded_file", filename=nama_file)

        proses = {
            "resize": resize,
            "crop": crop,
            "flip": flip,
            "gray": gray,
            "brightness": bright,
        }

        for nama, img in proses.items():
            nama_output = nama_unik + "_" + nama + ".jpg"
            path_output = os.path.join(OUTPUT_FOLDER, nama_output)
            cv2.imwrite(path_output, img)
            hasil[nama] = url_for("static_file", filename=nama_output)

    return render_template("index.html", hasil=hasil, error=None)


@app.errorhandler(413)
def file_terlalu_besar(e):
    return render_template(
        "index.html", hasil={},
        error="Ukuran file terlalu besar (maksimal 10 MB)!"
    ), 413


@app.route("/uploads/<filename>")
def uploaded_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)


@app.route("/hasil_foto/<filename>")
def static_file(filename):
    return send_from_directory(OUTPUT_FOLDER, filename)


if __name__ == "__main__":
    app.run(debug=True)
