# Aplikasi Web Pengolahan Foto Digital (Flask + Python + OpenCV)

Praktikum Grafika Komputer dan Pengolahan Citra - Pertemuan 9

## Struktur folder
```
praktikum_pengolahan_citra/
├── app.py
├── requirements.txt
├── README.md
├── templates/
│   └── index.html
├── uploads/        (dibuat otomatis)
└── hasil_foto/     (dibuat otomatis)
```

## Install library
```
pip install flask opencv-python
```
atau `pip install -r requirements.txt`

## Menjalankan aplikasi (Terminal)
```
cd praktikum_pengolahan_citra
python app.py
```

## Jika berhasil, akan muncul
```
Running on http://127.0.0.1:5000
```
Buka alamat tersebut di browser, upload foto JPG/PNG, lalu klik "Proses Gambar".
